import {React, useState} from 'react';
import '../../App.css';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Chip from '@material-ui/core/Chip';
import FeatureHelp from '../FeatureHelp/FeatureHelp';
import ResultBtn from './ResultBtn';



const features = ['1', '2', '3', '4', '5'];
// const corr_features = features.splice(index,);
let corr_array = [...features];

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },

  },
  
};


const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: '60%',

      /* maxWidth: 300, */
      
    },
    chips: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    chip: {
      margin: 2,
      color: 'teal',
      backgroundColor: 'whitesmoke',
      border: '1px solid teal',
      fontSize: '20px',
    },
    noLabel: {
      marginTop: theme.spacing(3),
    },
   
    CorrMenu: {
        color: 'teal',
        textAlign: 'left',
        fontSize: '20px',
    }
  }));



export default function FeatureDropdown(){
    const classes = useStyles();
    const theme = useTheme();
    
    const [mainFeat, setMainFeat] = useState();

    const selectMainFeat = (e) =>{
        /* let selection = document.querySelector('Select');
        let val = selection.options[selection.selectedIndex].value; */
        let val = e.target.value;
        setMainFeat(val);

    }

    /* const [corrFeat, setCorrFeat] = useState([]);

    const handleChange = (event) => {
        setCorrFeat(event.target.value);
        
    }; */


   /*  console.log('I am selected corr feats');
    console.log(corrFeat); */

    /* console.log('I am main feature');
    console.log(mainFeat); */

    let main_feat_index = features.indexOf(mainFeat);

    /* console.log('i am index');
    console.log(main_feat_index); */

    corr_array = [...features];
    corr_array.splice(main_feat_index,1 );

   /*  console.log('We are corr features:');
    console.log(corr_array); */

 

    return(
        <div>
            <FeatureHelp/>
            <div className='mainFeature'>

                <FormControl className={classes.formControl}>
                    <InputLabel id="simple-select-label">Main Feature</InputLabel>
                    <Select
                    className={classes.CorrMenu}
                    labelId="simple-select-label"
                    id="simple-select"
                    value={mainFeat}
                    onChange={selectMainFeat}
                    >
                    {features.map(feature => (
                            <MenuItem key={feature} value={feature}  >
                                {feature}
                            </MenuItem>
                    ))}
                    </Select>
                </FormControl>

            </div>

            {/* <div className='corrFeature'>
                <FormControl className={classes.formControl}>
                    <InputLabel id="demo-mutiple-chip-label" className={classes.InputLabel}>Corelational Elements</InputLabel>
                    <Select
                        className = {classes.selectStyle}
                        labelId="demo-mutiple-chip-label"
                        labelWidth='2'
                        id="demo-mutiple-chip"
                        multiple
                        value={corrFeat}
                        onChange={handleChange}
                        input={<Input id="select-multiple-chip" />}
                        renderValue={(selected) => (
                            <div className={classes.chips}>
                            {selected.map((value) => (
                                <Chip key={value} label={value} className={classes.chip} />
                            ))}
                            </div>
                        )}
                        MenuProps={MenuProps}
                    >
                    {corr_array.map((corrFeature) => (
                        <MenuItem key={corrFeature} value={corrFeature} >
                        {corrFeature}
                        </MenuItem>
                    ))}
                    </Select>
                    
                </FormControl>
                
                
            </div> */}
            <div><ResultBtn/></div>
            
        </div>
    )
}
