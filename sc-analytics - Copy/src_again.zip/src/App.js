import Navbar from './components//Navbar/Navbar';
import ContactUs from './components/ContactUs.js'
import './App.css';
import Button from '@material-ui/core/Button';
import {useState} from 'react';
import {Line} from 'react-chartjs-2';
import Dropdown from './components/FeatureDropdown/FeatureDropdown';
import About from './components/About/About';
import Contact from './components/Contact/Contact';
import Start from './components/Start/Start';
import Result from './components/Result/Result';
import {BrowserRouter, Route} from 'react-router-dom';

let dataset = {};
let display_results = {};
function App() {
  const [state, setState] = useState();
  const showFeatures = () =>{
    setState('features');
  }
  
  function calculate(e){
    e.preventDefault();
    let main= document.getElementById("mainFeat").value;
    const data_to_send = { name: main };
    fetch('http://127.0.0.1:5000', {
      method: 'POST',
      headers: {
        'Content-type': 'application/json',
      },
      body: JSON.stringify(data_to_send),

    })
      //.then(res => res.json())
      //.then(res => console.log(res))
      .then(function(response){
        if (response.status !== 200) {
          console.log("There was an error!");
          return;
        }
        response.json().then(function(data){
          console.log(data);
          display_results = data;
          dataset = {
            labels: data.max_event_vals,
            datasets: [
              {
                label: 'Maximized Event',
                fill: false,
                lineTension: 0.5,
                backgroundColor: 'rgba(75,192,192,1)',
                borderColor: 'rgba(0,0,0,1)',
                borderWidth: 2,
                data: data.goal_event_vals
              }
            ]
    
          } 
          setState('show');
          

        });
        
        

      })

      
      
    
    
      
    setState('calculate');
  }

  return (
    <BrowserRouter>
    
      <div className='wrapper'>
        <div style={{ 'paddingTop':'0px'}}>
          <Navbar/>

          <Route path="/" exact component={Start}/>
          <Route path="/about-us" exact component={About}/> 
          <Route path="/contact" exact component={Contact}/>

          {state=== 'features' && (<Route path="/feature-dropdown" exact component={Dropdown}/>)}
          

          

        

          {state === 'calculate' && (
                    <div>
                  <h1>Fetching.... Please Wait</h1>  
                  </div>
                  )}
          {state === 'show' && (
            <div style={{ marginLeft:'5%'}}>
                <h1> Your Regression Results</h1>
                    <Line
                      data={dataset}
                      options={{
                        title:{
                          display:true,
                          text:'Relationship between Best Correlation Event and Goal Event',
                          fontSize:20
                        },
                        legend:{
                          display:true,
                          position:'right'
                        }
                      }}
                    />
                  <div style={{ marginLeft:'10%', marginTop:'5%'}}>
                    <label> Maximum Correlational Event: {display_results.max}</label><br/>
                    <label> Optimum Value Using Random Forest Regression: {display_results.opt}</label><br/>
                    <label> Prediction for Optimum Value Using Random Forest Regression: {display_results.prediction}</label><br/>
                    <label> Optimum Value Using Linear Regression: {display_results.opt_lin}</label><br/>
                    <label> Prediction for Optimum Value Using Linear Regression: {display_results.prediction_lin}</label><br/>
                    <label> Root Mean Squared Error Using Random Forest Regression: {display_results.rmse_rf}</label><br/>
                    <label> Root Mean Squared Error Using Linear Regression: {display_results.prediction_lin}</label><br/>
                    <Link to='/feature-dropdown'>
                      <button className='start-btn' fullWidth='true' size='large' s3 onClick={showFeatures}>Back</button>
                    </Link>
                  </div>
            </div>
          )}
                
                  
                    
        </div>
      </div>
  </BrowserRouter>
  );
}

export default App;
