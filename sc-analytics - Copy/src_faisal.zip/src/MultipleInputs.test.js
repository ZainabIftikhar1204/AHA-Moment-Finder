import { cleanup, render, screen } from '@testing-library/react';
import Signin from './components/Signin';

afterEach(cleanup);
describe('Multiple Inputs component',() => {
    test('all fields should be null', () => {
        const {getByTestId} = render(<Signin/>)
        expect(getByTestId('username').value).toBe('');
        expect(getByTestId('password').value).toBe('');
        expect(getByTestId('email').value).toBe('');
    
      });
    
    test('if event handler is triggered')
})
 
